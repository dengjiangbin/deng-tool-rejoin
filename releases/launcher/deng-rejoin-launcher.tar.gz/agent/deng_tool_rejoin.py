#!/usr/bin/env python3
"""Stub entry — full tree arrives after first successful license-gated download."""
from __future__ import annotations
import sys
from pathlib import Path

_app_home = Path(__file__).resolve().parents[1]
if str(_app_home) not in sys.path:
    sys.path.insert(0, str(_app_home))

from agent.deferred_bundle_install import run  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run())
