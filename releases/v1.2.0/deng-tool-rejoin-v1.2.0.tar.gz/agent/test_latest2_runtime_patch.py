"""test/latest2-only runtime patch: Lime Delta key bypass on v1.3.0 base.

No stagger, cache-clear, Termux, resize, or monitoring overlays — those stay
exactly as shipped in ``refs/tags/v1.3.0``.
"""

from __future__ import annotations

import os
import threading
import time
from typing import Any

_PATCHED = False


def apply_test_latest2_runtime_patches() -> None:
    """Apply the single test/latest2 delta-bypass hook when lime is enabled."""
    global _PATCHED
    if _PATCHED:
        return
    try:
        from .lime_channel import lime_detection_enabled
    except Exception:  # noqa: BLE001
        return
    if not lime_detection_enabled():
        return
    if not _patch_delta_bypass_at_start():
        return
    _PATCHED = True


def _sync_perform_rejoin_bindings(wrapped: Any) -> None:
    """Keep ``commands`` / ``supervisor`` using the patched launcher hook."""
    for modname in ("commands", "supervisor"):
        try:
            mod = __import__(f"agent.{modname}", fromlist=[modname])
            if hasattr(mod, "perform_rejoin"):
                mod.perform_rejoin = wrapped  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            continue


def _patch_delta_bypass_at_start() -> bool:
    """Hook first-clone Start: OCR → Receive Key → token → inject → relaunch."""
    try:
        from . import launcher as launcher_mod
    except Exception:  # noqa: BLE001
        return False
    if getattr(launcher_mod, "_test_latest2_lime_bypass_patched", False):
        return True

    orig = launcher_mod.perform_rejoin
    launcher_mod._test_latest2_orig_perform_rejoin = orig

    def _perform_rejoin_with_lime_bypass(
        config_data: dict[str, Any],
        *,
        reason: str = "manual",
        package_entry: dict[str, Any] | None = None,
        no_force_stop: bool = False,
    ) -> Any:
        pkg = str((package_entry or {}).get("package") or config_data.get("roblox_package") or "")
        launch_finished = threading.Event()
        bypass_thread: threading.Thread | None = None

        if reason == "start" and pkg:
            try:
                from .lime_delta_key_bypass import (
                    is_first_stagger_package,
                    log_delta_bypass_event,
                    run_lime_delta_bypass_flow,
                )

                if is_first_stagger_package(pkg, config_data):

                    def _background_bypass() -> None:
                        try:
                            try:
                                delay = float(
                                    os.environ.get("DENG_REJOIN_DELTA_BYPASS_DELAY_SEC", "8")
                                    or "8"
                                )
                            except ValueError:
                                delay = 8.0
                            log_delta_bypass_event(
                                "thread_started",
                                package=pkg,
                                delay_sec=delay,
                            )
                            if delay > 0:
                                time.sleep(min(30.0, max(0.0, delay)))
                            flow = run_lime_delta_bypass_flow(
                                pkg,
                                config_data,
                                launch_finished=launch_finished,
                            )
                            if flow.get("relaunch_requested"):
                                orig(
                                    config_data,
                                    reason=reason,
                                    package_entry=package_entry,
                                    no_force_stop=no_force_stop,
                                )
                        except Exception as exc:  # noqa: BLE001
                            log_delta_bypass_event(
                                "thread_error",
                                package=pkg,
                                error=str(exc)[:120],
                            )

                    bypass_thread = threading.Thread(
                        target=_background_bypass,
                        name=f"lime-delta-bypass-{pkg}",
                        daemon=True,
                    )
                    bypass_thread.start()
                    log_delta_bypass_event("thread_spawned", package=pkg)
            except Exception as exc:  # noqa: BLE001
                try:
                    from .lime_delta_key_bypass import log_delta_bypass_event

                    log_delta_bypass_event(
                        "spawn_failed",
                        package=pkg,
                        error=str(exc)[:120],
                    )
                except Exception:  # noqa: BLE001
                    pass

        try:
            result = orig(
                config_data,
                reason=reason,
                package_entry=package_entry,
                no_force_stop=no_force_stop,
            )
        finally:
            launch_finished.set()

        if bypass_thread is None:
            return result
        if reason != "start" or not getattr(result, "success", getattr(result, "ok", False)):
            return result
        return result

    launcher_mod.perform_rejoin = _perform_rejoin_with_lime_bypass  # type: ignore[assignment]
    _sync_perform_rejoin_bindings(launcher_mod.perform_rejoin)
    launcher_mod._test_latest2_lime_bypass_patched = True
    return True
