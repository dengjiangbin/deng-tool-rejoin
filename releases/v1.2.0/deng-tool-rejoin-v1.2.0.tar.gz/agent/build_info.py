"""Runtime build-proof helpers for DENG Tool: Rejoin.

The tool reads two on-disk files to prove which build is actually running on
the device:

* ``BUILD-INFO.json`` — embedded inside the published tarball by
  :func:`agent.internal_test_artifact.build_internal_test_tarball`.  Carries
  the git commit + build time + channel.  This file is shipped with the code
  and is always co-located with ``agent/`` after install.

* ``.installed-build.json`` — written by the installer bash script at install
  time, sitting at the install-root (one level above ``agent/``).  Carries
  the verified ``artifact_sha256``, ``install_time``, ``package_url`` and
  ``installer_url`` that the installer just downloaded.

``deng-rejoin version`` and ``deng-rejoin doctor install`` consume the merged
view from this module.  The functions here have no side effects and use only
the standard library so that even when modules are partially broken the
version / doctor commands still run.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import marshal
import zlib
from pathlib import Path
from typing import Any

# ─── Paths ─────────────────────────────────────────────────────────────────────
# install root = directory containing this ``agent`` package
INSTALL_ROOT = Path(__file__).resolve().parent.parent
BUILD_INFO_PATH = INSTALL_ROOT / "BUILD-INFO.json"
INSTALLED_BUILD_PATH = INSTALL_ROOT / ".installed-build.json"
INSTALL_API_PATH = INSTALL_ROOT / ".install_api"
RELEASE_MANIFEST_PATH = INSTALL_ROOT / "RELEASE-MANIFEST.json"
PROTECTED_RUNTIME_PATH = INSTALL_ROOT / "agent" / ".deng_runtime.bin"


def _read_json(path: Path) -> dict[str, Any]:
    try:
        if not path.is_file():
            return {}
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def load_build_info() -> dict[str, Any]:
    """Load the embedded ``BUILD-INFO.json``; empty dict if missing."""
    return _read_json(BUILD_INFO_PATH)


def load_installed_build() -> dict[str, Any]:
    """Load the installer-written ``.installed-build.json``; empty if missing."""
    return _read_json(INSTALLED_BUILD_PATH)


def _read_install_api() -> str:
    try:
        if not INSTALL_API_PATH.is_file():
            return ""
        return INSTALL_API_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def find_wrapper_path() -> str | None:
    """Best-effort: where the ``deng-rejoin`` shell wrapper lives on PATH."""
    return shutil.which("deng-rejoin")


# ─── Required modules / symbols that prove the new build is loaded ────────────

# Per task: doctor install must verify these modules exist and these symbols
# resolve.  Adding a key here is the only way to make a feature mandatory.
REQUIRED_MODULES: tuple[str, ...] = (
    "agent.commands",
    "agent.supervisor",
    "agent.roblox_presence",
    "agent.window_apply",
    "agent.freeform_enable",
    "agent.playing_state",
    "agent.dumpsys_cache",
    "agent.android",
    "agent.launcher",
    "agent.termux_minimize",
)

# (module, symbol) pairs that must resolve at import time.
REQUIRED_SYMBOLS: tuple[tuple[str, str], ...] = (
    ("agent.roblox_presence", "fetch_presence"),
    ("agent.roblox_presence", "lookup_user_id"),
    ("agent.dumpsys_cache", "cached_run"),
    ("agent.freeform_enable", "setup_freeform_capabilities"),
    ("agent.playing_state", "StateTracker"),
    ("agent.android", "launch_package_with_bounds"),
    ("agent.termux_minimize", "minimize_termux_to_dock"),
)


def _module_file_path(modname: str) -> str | None:
    """Return the on-disk ``__file__`` for *modname* without importing it.

    We resolve through ``importlib.util.find_spec`` so a missing module simply
    returns ``None`` and never raises during ``doctor install``.
    """
    try:
        import importlib.util

        spec = importlib.util.find_spec(modname)
        if spec is None or not spec.origin:
            return None
        return spec.origin
    except Exception:  # noqa: BLE001 — best-effort probe.
        return None


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(64 * 1024), b""):
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()


def _short(sha: str, n: int = 12) -> str:
    sha = (sha or "").strip()
    return sha[:n] if sha else ""


def _load_release_manifest() -> dict[str, Any]:
    return _read_json(RELEASE_MANIFEST_PATH)


def _iter_code_objects(root: Any):
    stack = [root]
    while stack:
        item = stack.pop()
        yield item
        for const in getattr(item, "co_consts", ()):
            if hasattr(const, "co_consts"):
                stack.append(const)


def _code_object_facts(root: Any) -> dict[str, set[str]]:
    names: set[str] = set()
    strings: set[str] = set()
    for code in _iter_code_objects(root):
        co_name = getattr(code, "co_name", "")
        if co_name:
            names.add(str(co_name))
        for name in getattr(code, "co_names", ()):
            names.add(str(name))
        for const in getattr(code, "co_consts", ()):
            if isinstance(const, str):
                strings.add(const)
    return {"names": names, "strings": strings}


def _load_protected_modules() -> dict[str, Any] | None:
    """Return the unmarshalled protected-runtime module map, or ``None``."""
    if not PROTECTED_RUNTIME_PATH.is_file():
        return None
    try:
        modules = marshal.loads(zlib.decompress(PROTECTED_RUNTIME_PATH.read_bytes()))
    except Exception:  # noqa: BLE001
        return None
    return modules if isinstance(modules, dict) else None


def verify_runtime_bundle_integrity() -> None:
    """Install-time probe: protected bundle contains required modules/symbols.

    The installer must **not** import ``agent.commands`` or other heavy modules
    inline.  On Termux/cloud phones (Python 3.13 + bionic) that import graph can
    SIGSEGV during install verification even though the installed build is fine.
    This function inspects the marshalled bundle only — no network, no subprocess,
    no full module execution.  Call ``agent._protected_runtime._verify()`` first
    for manifest signature checks.
    """
    modules = _load_protected_modules()
    if not modules:
        raise SystemExit(1)
    missing_modules = [mod for mod in REQUIRED_MODULES if mod not in modules]
    if missing_modules:
        raise SystemExit(1)
    missing_symbols: list[str] = []
    for mod, sym in REQUIRED_SYMBOLS:
        code = modules.get(mod)
        if code is None:
            missing_symbols.append(f"{mod}.{sym}")
            continue
        if sym not in _code_object_facts(code)["names"]:
            missing_symbols.append(f"{mod}.{sym}")
    if missing_symbols:
        raise SystemExit(1)
    runtime = inspect_protected_runtime()
    if runtime.get("monitor_command_implementation") != "persistent_worker":
        raise SystemExit(1)


def inspect_protected_runtime() -> dict[str, Any]:
    info: dict[str, Any] = {
        "present": PROTECTED_RUNTIME_PATH.is_file(),
        "sha256": "",
        "sha256_short": "",
        "module_count": 0,
        "monitor_worker_present": False,
        "monitor_command_implementation": "missing",
        "persistent_worker_command_available": False,
        "legacy_shell_path_reachable": False,
        "monitor_detector_detail": "protected runtime missing",
        "bridge_launcher_path": str(INSTALL_ROOT / "agent" / "deng_tool_rejoin.py"),
    }
    if not PROTECTED_RUNTIME_PATH.is_file():
        return info
    info["sha256"] = _hash_file(PROTECTED_RUNTIME_PATH)
    info["sha256_short"] = _short(info["sha256"])
    modules = _load_protected_modules()
    if modules is None:
        info["monitor_command_implementation"] = "unreadable"
        return info
    info["module_count"] = len(modules)
    commands_code = modules.get("agent.commands")
    if commands_code is None:
        info["monitor_command_implementation"] = "missing_commands"
        info["monitor_detector_detail"] = "agent.commands missing from protected runtime"
        return info
    facts = _code_object_facts(commands_code)
    names = facts["names"]
    strings = facts["strings"]
    required_names = {
        "_cmd_monitor_run_worker",
        "_spawn_monitor_worker",
        "_monitor_worker_running",
        "_monitor_status_from_disk",
        "_stop_monitor_worker",
        "_MONITOR_WORKER_ENV",
    }
    required_strings = {"run-worker", "monitor-run-worker"}
    missing_names = sorted(required_names - names)
    missing_strings = sorted(s for s in required_strings if not any(s in item for item in strings))
    info["persistent_worker_command_available"] = not missing_names and not missing_strings
    info["monitor_worker_present"] = bool(info["persistent_worker_command_available"])
    # Old builds launched a shell status/start shim. Keeping historical strings
    # in help text must not make the current persistent worker look legacy.
    info["legacy_shell_path_reachable"] = any(
        marker in item
        for item in strings
        for marker in ("monitor-autostart.sh", "monitor-status.sh")
    )
    info["monitor_detector_detail"] = (
        "persistent worker symbols present"
        if info["persistent_worker_command_available"]
        else f"missing names={missing_names or '-'} strings={missing_strings or '-'}"
    )
    info["monitor_command_implementation"] = (
        "persistent_worker" if info["monitor_worker_present"] else "legacy_shell"
    )
    return info


def _wrapper_target_install_root() -> str | None:
    """Inspect the wrapper script and try to extract its install-root path.

    The wrapper we generate exports ``DENG_REJOIN_HOME=...`` and ultimately
    executes ``$DENG_REJOIN_HOME/agent/deng_tool_rejoin.py``.  Older wrappers
    set ``APP_HOME=...`` instead.  Return the path string if discoverable
    (with bash parameter expansion stripped to its default value), else
    ``None``.
    """
    wrapper = find_wrapper_path()
    if not wrapper:
        return None
    try:
        text = Path(wrapper).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    for line in text.splitlines():
        s = line.strip()
        # Examples we accept:
        #   export DENG_REJOIN_HOME="${DENG_REJOIN_HOME:-$HOME/.deng-tool/rejoin}"
        #   DENG_REJOIN_HOME="$HOME/.deng-tool/rejoin"
        #   APP_HOME="$HOME/.deng-tool/rejoin"
        for prefix in ("export DENG_REJOIN_HOME=", "DENG_REJOIN_HOME=", "APP_HOME="):
            if s.startswith(prefix):
                raw = s[len(prefix):].strip().strip('"').strip("'")
                # Strip ${VAR:-default} → default
                if raw.startswith("${") and ":-" in raw and raw.endswith("}"):
                    raw = raw[raw.index(":-") + 2 : -1]
                return raw
    return None


def collect_version_info() -> dict[str, Any]:
    """Return the merged dict consumed by ``deng-rejoin version``.

    Never raises; missing pieces produce empty strings.
    """
    from .constants import VERSION, PRODUCT_NAME

    bi = load_build_info()
    ib = load_installed_build()
    manifest = _load_release_manifest()
    runtime = inspect_protected_runtime()
    product_version = str(
        ib.get("version")
        or bi.get("version")
        or manifest.get("version")
        or VERSION
        or ""
    )
    info: dict[str, Any] = {
        "product": PRODUCT_NAME,
        "product_version": product_version,
        "channel": str(ib.get("channel") or bi.get("channel") or ""),
        "source_version": str(bi.get("source_version") or ib.get("source_version") or ""),
        "git_commit": str(ib.get("git_commit") or bi.get("git_commit") or ""),
        "git_commit_short": _short(
            str(ib.get("git_commit") or bi.get("git_commit") or "")
        ),
        "artifact_sha256": str(ib.get("artifact_sha256") or ""),
        "artifact_sha256_short": _short(str(ib.get("artifact_sha256") or "")),
        "built_at_iso": str(bi.get("built_at_iso") or ""),
        "install_time_iso": str(ib.get("install_time_iso") or ""),
        "install_api": str(ib.get("install_api") or _read_install_api() or ""),
        "package_url": str(ib.get("package_url") or ""),
        "installer_url": str(ib.get("installer_url") or ""),
        "install_root": str(INSTALL_ROOT),
        "python_executable": sys.executable,
        "python_version": sys.version.split()[0],
        "wrapper_path": find_wrapper_path() or "",
        "wrapper_target_root": _wrapper_target_install_root() or "",
        "build_info_path": str(BUILD_INFO_PATH) if BUILD_INFO_PATH.is_file() else "",
        "installed_build_path": str(INSTALLED_BUILD_PATH)
        if INSTALLED_BUILD_PATH.is_file()
        else "",
        "release_manifest_path": str(RELEASE_MANIFEST_PATH) if RELEASE_MANIFEST_PATH.is_file() else "",
        "release_manifest_sha256": _hash_file(RELEASE_MANIFEST_PATH) if RELEASE_MANIFEST_PATH.is_file() else "",
        "release_manifest_sha256_short": _short(_hash_file(RELEASE_MANIFEST_PATH)) if RELEASE_MANIFEST_PATH.is_file() else "",
        "runtime_build_date": str(bi.get("built_at_iso") or ""),
        "protected_runtime_present": runtime.get("present", False),
        "protected_runtime_sha256": runtime.get("sha256") or "",
        "protected_runtime_sha256_short": runtime.get("sha256_short") or "",
        "protected_runtime_module_count": runtime.get("module_count") or 0,
        "monitor_worker_present": runtime.get("monitor_worker_present", False),
        "monitor_command_implementation": runtime.get("monitor_command_implementation") or "missing",
        "persistent_worker_command_available": runtime.get("persistent_worker_command_available", False),
        "legacy_shell_path_reachable": runtime.get("legacy_shell_path_reachable", False),
        "monitor_detector_detail": runtime.get("monitor_detector_detail") or "",
        "bridge_launcher_path": runtime.get("bridge_launcher_path") or "",
        "release_manifest_version": str(manifest.get("version") or ""),
        "modules": {},
    }
    for mod in REQUIRED_MODULES:
        info["modules"][mod] = _module_file_path(mod) or ""
    return info


# ─── doctor install ────────────────────────────────────────────────────────────


def _orphan_pycache_dirs() -> list[str]:
    """Find ``__pycache__`` directories where the parent has no matching ``.py``.

    These are leftover compiled modules from a previous install and they can
    silently shadow source-not-present imports on some Pythons.  The installer
    purges them; doctor install reports them.
    """
    out: list[str] = []
    for root in (INSTALL_ROOT / "agent", INSTALL_ROOT / "bot", INSTALL_ROOT / "scripts"):
        if not root.is_dir():
            continue
        for pyc_dir in root.rglob("__pycache__"):
            try:
                for pyc in pyc_dir.iterdir():
                    if pyc.suffix != ".pyc":
                        continue
                    # __pycache__/foo.cpython-311.pyc → foo.py expected in parent
                    name = pyc.stem.split(".")[0] + ".py"
                    if not (pyc_dir.parent / name).is_file():
                        out.append(str(pyc))
            except OSError:
                continue
    return out


def doctor_install_checks() -> list[dict[str, Any]]:
    """Run the doctor-install probes and return one dict per check.

    Each dict has keys: ``name`` (str), ``ok`` (bool), ``detail`` (str).
    """
    out: list[dict[str, Any]] = []

    # 1) wrapper present
    wrapper = find_wrapper_path()
    out.append(
        {
            "name": "wrapper_present",
            "ok": bool(wrapper),
            "detail": wrapper or "deng-rejoin not on PATH",
        }
    )

    # 2) wrapper APP_HOME matches our install root
    wrapper_root = _wrapper_target_install_root()
    if wrapper_root:
        # Compare normalised paths; tolerate trailing slashes and Termux vars.
        expanded = os.path.expandvars(os.path.expanduser(wrapper_root))
        ok = Path(expanded).resolve() == INSTALL_ROOT
        out.append(
            {
                "name": "wrapper_targets_install_root",
                "ok": ok,
                "detail": f"wrapper APP_HOME={wrapper_root} install_root={INSTALL_ROOT}",
            }
        )

    # 3) BUILD-INFO.json present
    bi = load_build_info()
    out.append(
        {
            "name": "build_info_present",
            "ok": bool(bi),
            "detail": str(BUILD_INFO_PATH) if bi else "missing BUILD-INFO.json",
        }
    )

    # 4) .installed-build.json present
    ib = load_installed_build()
    out.append(
        {
            "name": "installed_build_metadata",
            "ok": bool(ib),
            "detail": str(INSTALLED_BUILD_PATH) if ib else "missing .installed-build.json",
        }
    )

    # 5) artifact SHA recorded by installer
    sha_present = bool(str(ib.get("artifact_sha256") or "").strip())
    out.append(
        {
            "name": "artifact_sha_recorded",
            "ok": sha_present,
            "detail": _short(str(ib.get("artifact_sha256") or "")) or "no SHA",
        }
    )

    # 6) Required modules importable (we use find_spec — no side effects).
    missing_modules: list[str] = []
    for mod in REQUIRED_MODULES:
        if not _module_file_path(mod):
            missing_modules.append(mod)
    out.append(
        {
            "name": "required_modules_present",
            "ok": not missing_modules,
            "detail": "all present" if not missing_modules else f"missing: {', '.join(missing_modules)}",
        }
    )

    # 7) Required symbols resolvable on import.
    missing_symbols: list[str] = []
    for mod, sym in REQUIRED_SYMBOLS:
        try:
            import importlib

            m = importlib.import_module(mod)
            if not hasattr(m, sym):
                missing_symbols.append(f"{mod}.{sym}")
        except Exception:  # noqa: BLE001
            missing_symbols.append(f"{mod}.{sym}")
    out.append(
        {
            "name": "required_symbols_resolvable",
            "ok": not missing_symbols,
            "detail": "all resolve"
            if not missing_symbols
            else f"missing: {', '.join(missing_symbols)}",
        }
    )

    # 8) No orphan __pycache__ shadowing missing sources.
    orphans = _orphan_pycache_dirs()
    out.append(
        {
            "name": "no_orphan_pycache",
            "ok": not orphans,
            "detail": "clean" if not orphans else f"{len(orphans)} orphan .pyc files",
        }
    )

    # 9) No stale "deferred installer" path from earlier builds.
    stale_candidates = [
        INSTALL_ROOT / "deferred_install.py",
        INSTALL_ROOT / "deferred_installer.py",
        INSTALL_ROOT / "agent" / "deferred_install.py",
        INSTALL_ROOT / "scripts" / "deferred_install.sh",
    ]
    stale = [str(p) for p in stale_candidates if p.is_file()]
    out.append(
        {
            "name": "no_stale_deferred_installer",
            "ok": not stale,
            "detail": "clean" if not stale else f"found: {', '.join(stale)}",
        }
    )

    # 10) Modules resolve under INSTALL_ROOT (not from some other PYTHONPATH).
    misrouted: list[str] = []
    for mod in REQUIRED_MODULES:
        p = _module_file_path(mod)
        if not p:
            continue
        try:
            Path(p).resolve().relative_to(INSTALL_ROOT)
        except ValueError:
            misrouted.append(f"{mod}={p}")
    out.append(
        {
            "name": "modules_under_install_root",
            "ok": not misrouted,
            "detail": "all routed correctly"
            if not misrouted
            else f"shadowed: {', '.join(misrouted)}",
        }
    )

    # 11) BUILD-INFO.json contains probe_id (proves this is a hardened build).
    probe_id = str(bi.get("probe_id") or "").strip()
    out.append(
        {
            "name": "build_info_has_probe_id",
            "ok": bool(probe_id and probe_id.startswith("p-")),
            "detail": probe_id if probe_id else "BUILD-INFO.json missing probe_id",
        }
    )

    # 12) No legacy experience_detector imported by live supervisor.
    sv_path = _module_file_path("agent.supervisor")
    legacy_ok = True
    legacy_detail = "clean"
    if sv_path:
        try:
            import re as _re

            sv_src = "" if "agent/supervisor.py" in sv_path.replace("\\", "/") else Path(sv_path).read_text(encoding="utf-8", errors="replace")
            # Match actual import statements, not comments
            if _re.search(r"^\s*(?:from|import)[^\n#]*experience_detector", sv_src, _re.MULTILINE):
                legacy_ok = False
                legacy_detail = f"supervisor imports experience_detector ({sv_path})"
        except OSError:
            legacy_detail = "could not read supervisor source"
    out.append(
        {
            "name": "no_legacy_detector_in_supervisor",
            "ok": legacy_ok,
            "detail": legacy_detail,
        }
    )

    # 13) No Joining / Join Unconfirmed state names present in live supervisor.
    joining_ok = True
    joining_detail = "clean"
    if sv_path:
        try:
            import re as _re

            sv_src = "" if "agent/supervisor.py" in sv_path.replace("\\", "/") else Path(sv_path).read_text(encoding="utf-8", errors="replace")
            # Detect literal string "Joining" or "Join Unconfirmed" as state values
            matches: list[str] = []
            if _re.search(r"""['"](Joining)['"]\s*[,)]""", sv_src):
                matches.append("Joining")
            if _re.search(r"""['"](Join Unconfirmed)['"]\s*[,)]""", sv_src):
                matches.append("Join Unconfirmed")
            if matches:
                joining_ok = False
                joining_detail = f"forbidden state names in supervisor: {', '.join(matches)}"
        except OSError:
            joining_detail = "could not read supervisor source"
    out.append(
        {
            "name": "no_joining_state_in_supervisor",
            "ok": joining_ok,
            "detail": joining_detail,
        }
    )

    # 14) No ANY __pycache__ directories under INSTALL_ROOT (all should be gone post-install).
    pycache_dirs: list[str] = []
    for root_dir in (INSTALL_ROOT / "agent", INSTALL_ROOT / "bot"):
        if not root_dir.is_dir():
            continue
        try:
            for pc in root_dir.rglob("__pycache__"):
                if pc.is_dir():
                    pycache_dirs.append(str(pc))
        except OSError:
            pass
    out.append(
        {
            "name": "no_pycache_dirs",
            "ok": not pycache_dirs,
            "detail": "clean"
            if not pycache_dirs
            else f"{len(pycache_dirs)} __pycache__ dirs remain",
        }
    )

    return out


def doctor_install_overall_ok(results: list[dict[str, Any]]) -> bool:
    """Return ``True`` only if every entry's ``ok`` is truthy."""
    return all(bool(r.get("ok")) for r in results)


# Alias used in commands.py (collect vs collected — keep both working)
collected_version_info = collect_version_info
