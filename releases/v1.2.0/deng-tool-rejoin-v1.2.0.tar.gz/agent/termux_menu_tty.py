"""Termux menu TTY alignment — fixes diagonal 1/2/3 menu drift after install/Start."""

from __future__ import annotations

from typing import Any

_APPLIED = False


def apply_termux_menu_tty_fix() -> None:
    """Ensure menu lines always start at column 0 on Termux (idempotent)."""
    global _APPLIED
    if _APPLIED:
        return
    try:
        from . import safe_io
    except Exception:  # noqa: BLE001
        return
    if not safe_io._on_termux():
        return

    _patch_safe_io_onlcr(safe_io)
    _patch_safe_io_block_write(safe_io)
    _patch_safe_io_line_write(safe_io)
    _patch_termux_ui_emit()
    _patch_menu_print()
    _patch_banner_print()
    _APPLIED = True


def reset_before_menu_paint() -> None:
    """Restore TTY output mapping and clear the visible screen once."""
    try:
        from . import safe_io
    except Exception:  # noqa: BLE001
        return
    if hasattr(safe_io, "reset_termux_menu_terminal"):
        safe_io.reset_termux_menu_terminal()
        return
    safe_io.restore_terminal()
    _stty_onlcr()
    safe_io.safe_clear_screen(clear_scrollback=False)


def write_menu_lines(lines: list[str]) -> None:
    """Write many menu lines as one frame; each row starts at column 0 on Termux."""
    write_termux_block(
        "\n".join(str(raw or "") for raw in lines) + ("\n" if lines else "")
    )


def _stty_onlcr() -> None:
    if __import__("os").name == "nt":
        return
    try:
        from . import subprocess_isolated as _iso  # noqa: PLC0415

        for args in (
            ["stty", "-F", "/dev/tty", "onlcr", "opost", "sane"],
            ["stty", "onlcr", "opost", "sane"],
        ):
            try:
                _iso.run_isolated_text(args, timeout=2.0)
                return
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        pass


def write_termux_block(text: str) -> None:
    """Normalize a multi-line stdout block so every row starts at column 0."""
    try:
        from . import safe_io, termux_ui
    except Exception:  # noqa: BLE001
        return
    if not safe_io._on_termux():
        _orig_block = getattr(safe_io, "_termux_menu_orig_write_stdout_block", safe_io.write_stdout_block)
        _orig_block(text)
        return
    parts: list[str] = []
    for raw in text.splitlines():
        line = str(raw or "")
        if not line:
            parts.append("\r\n")
        else:
            parts.append(f"\033[2K\r{termux_ui.fit_line(line)}\r\n")
    payload = "".join(parts)
    _orig_block = getattr(safe_io, "_termux_menu_orig_write_stdout_block", safe_io.write_stdout_block)
    _orig_block(payload)


def write_termux_line(text: str = "", *, end: str = "\n") -> None:
    try:
        from . import safe_io, termux_ui
    except Exception:  # noqa: BLE001
        return
    line = termux_ui.fit_line(str(text or ""))
    _orig = getattr(safe_io, "_termux_menu_orig_write_stdout", safe_io.write_stdout)
    if safe_io._on_termux():
        suffix = "\r\n" if end else ""
        _orig(f"\033[2K\r{line}", end=suffix)
        return
    _orig(line, end=end)


def _patch_safe_io_block_write(safe_io: Any) -> None:
    if getattr(safe_io, "_termux_menu_block_patched", False):
        return
    _orig = safe_io.write_stdout_block
    safe_io._termux_menu_orig_write_stdout_block = _orig

    def _block(text: str, *, flush: bool = True) -> None:
        if safe_io._on_termux():
            write_termux_block(text)
            return
        _orig(text, flush=flush)

    safe_io.write_stdout_block = _block  # type: ignore[assignment]
    safe_io._termux_menu_block_patched = True


def _patch_safe_io_line_write(safe_io: Any) -> None:
    if getattr(safe_io, "_termux_menu_line_patched", False):
        return
    _orig = safe_io.write_stdout
    safe_io._termux_menu_orig_write_stdout = _orig

    def _line(text: str = "", *, end: str = "\n", flush: bool = True) -> None:
        if safe_io._on_termux() and end in {"\n", "\r\n"}:
            write_termux_line(text, end=end if end == "\r\n" else "\n")
            return
        _orig(text, end=end, flush=flush)

    safe_io.write_stdout = _line  # type: ignore[assignment]
    safe_io._termux_menu_line_patched = True


def _patch_safe_io_onlcr(safe_io: Any) -> None:
    if getattr(safe_io, "_termux_menu_onlcr_patched", False):
        return
    _orig_restore = safe_io.restore_terminal

    def _restore_with_onlcr() -> None:
        _orig_restore()
        _stty_onlcr()

    safe_io.restore_terminal = _restore_with_onlcr  # type: ignore[assignment]
    safe_io._termux_menu_onlcr_patched = True


def _patch_termux_ui_emit() -> None:
    try:
        from . import safe_io, termux_ui
    except Exception:  # noqa: BLE001
        return
    if getattr(termux_ui, "_termux_menu_emit_patched", False):
        return

    def _emit(text: str = "") -> None:
        line = termux_ui.fit_line(text)
        if safe_io._on_termux():
            safe_io.write_stdout(f"\033[2K\r{line}", end="\r\n")
        else:
            safe_io.write_stdout(line, end="\n")

    termux_ui._emit = _emit  # type: ignore[assignment]
    termux_ui._termux_menu_emit_patched = True


def _patch_menu_print() -> None:
    try:
        from . import banner, menu, termux_ui
    except Exception:  # noqa: BLE001
        return
    if getattr(menu, "_termux_menu_print_patched", False):
        return

    def _print_menu(
        args: Any,
        prelude_lines: list[str] | None = None,
    ) -> None:
        reset_before_menu_paint()
        lines = banner.banner_text(use_color=True).splitlines()
        lines.append("")
        if prelude_lines:
            for line in prelude_lines:
                if line.startswith("[!]"):
                    lines.append(termux_ui.warning_line(line))
                else:
                    lines.append(
                        termux_ui.warning_line(line)
                        if "required" in line.lower()
                        else line
                    )
            lines.append("")
        lines.extend(
            [
                termux_ui.menu_number("1", "First Time Setup Config"),
                termux_ui.menu_number("2", "Setup / Edit Config"),
                termux_ui.menu_number("3", "Start"),
                termux_ui.menu_number("0", "Exit"),
                "",
            ]
        )
        write_menu_lines(lines)

    menu.print_menu = _print_menu  # type: ignore[assignment]
    menu._termux_menu_print_patched = True


def _patch_banner_print() -> None:
    try:
        from . import banner
    except Exception:  # noqa: BLE001
        return
    if getattr(banner, "_termux_menu_banner_patched", False):
        return

    def _print_banner(*, use_color: bool | None = None) -> None:
        write_menu_lines(banner.banner_text(use_color=use_color).splitlines())

    banner.print_banner = _print_banner  # type: ignore[assignment]
    banner._termux_menu_banner_patched = True
