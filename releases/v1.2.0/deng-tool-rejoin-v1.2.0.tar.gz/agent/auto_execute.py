"""Filesystem-only Auto Execute management for executor auto-run folders.

This module never executes Lua/script content.  It only writes/removes
DENG-managed files under known executor autoexecute directories.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

DEFAULT_ANDROID_STORAGE_ROOT = Path("/storage/emulated/0")
MANAGED_PREFIX = "deng_autoexec_"
MANAGED_SUFFIX = ".lua"
MANAGED_RE = re.compile(r"^deng_autoexec_(\d{3})\.lua$")


@dataclass(frozen=True)
class ExecutorSpec:
    key: str
    label: str
    autoexecute_subpath: str

    def autoexecute_dir(self, package: str, *, storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT) -> Path:
        return storage_root / "Android" / "data" / package / self.autoexecute_subpath


EXECUTORS: dict[str, ExecutorSpec] = {
    "delta": ExecutorSpec(
        key="delta",
        label="Delta",
        autoexecute_subpath="files/gloop/external/Autoexecute",
    ),
}


def executor_choices() -> list[ExecutorSpec]:
    return list(EXECUTORS.values())


def get_executor(key: str) -> ExecutorSpec:
    try:
        return EXECUTORS[key]
    except KeyError as exc:
        raise ValueError(f"Unsupported Auto Execute executor: {key}") from exc


def delta_autoexecute_dir(package: str, *, storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT) -> Path:
    return EXECUTORS["delta"].autoexecute_dir(package, storage_root=storage_root)


def configured_package_names(config_data: dict[str, Any]) -> list[str]:
    packages: list[str] = []
    for entry in config_data.get("roblox_packages") or []:
        if isinstance(entry, dict):
            if entry.get("enabled") is False:
                continue
            package = str(entry.get("package") or "").strip()
        else:
            package = str(entry or "").strip()
        if package and package not in packages:
            packages.append(package)
    if not packages:
        package = str(config_data.get("roblox_package") or "").strip()
        if package:
            packages.append(package)
    return packages


def managed_filename(index: int) -> str:
    return f"{MANAGED_PREFIX}{max(1, int(index)):03d}{MANAGED_SUFFIX}"


def _managed_index(path_or_name: Path | str) -> int | None:
    name = path_or_name.name if isinstance(path_or_name, Path) else str(path_or_name)
    match = MANAGED_RE.match(name)
    if not match:
        return None
    return int(match.group(1))


def is_managed_filename(path_or_name: Path | str) -> bool:
    return _managed_index(path_or_name) is not None


def _existing_managed_files(directory: Path) -> list[Path]:
    try:
        if not directory.is_dir():
            return []
        return sorted(
            [p for p in directory.iterdir() if p.is_file() and is_managed_filename(p.name)],
            key=lambda p: p.name,
        )
    except OSError:
        return []


def list_managed_filenames(
    packages: Iterable[str],
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
) -> list[str]:
    spec = get_executor(executor)
    names: set[str] = set()
    for package in packages:
        for path in _existing_managed_files(spec.autoexecute_dir(package, storage_root=storage_root)):
            names.add(path.name)
    return sorted(names)


def managed_filenames_by_package(
    packages: Iterable[str],
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
) -> dict[str, list[str]]:
    """Return DENG-managed script filenames per package, never file contents."""
    spec = get_executor(executor)
    out: dict[str, list[str]] = {}
    for package in packages:
        directory = spec.autoexecute_dir(package, storage_root=storage_root)
        out[package] = [path.name for path in _existing_managed_files(directory)]
    return out


def filenames_mismatch(inventory: dict[str, list[str]]) -> bool:
    """True when configured packages do not share the same managed filenames."""
    if len(inventory) <= 1:
        return False
    sets = {tuple(names) for names in inventory.values()}
    return len(sets) > 1


def next_managed_filename(
    packages: Iterable[str],
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
) -> str:
    indexes: list[int] = []
    spec = get_executor(executor)
    for package in packages:
        directory = spec.autoexecute_dir(package, storage_root=storage_root)
        for path in _existing_managed_files(directory):
            idx = _managed_index(path)
            if idx is not None:
                indexes.append(idx)
    return managed_filename((max(indexes) if indexes else 0) + 1)


def _script_bytes(script: str) -> bytes:
    text = str(script)
    if not text.endswith("\n"):
        text += "\n"
    return text.encode("utf-8")


def write_script_to_packages(
    packages: Iterable[str],
    script: str,
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
    filename: str | None = None,
) -> list[dict[str, Any]]:
    """Write one DENG-managed script file to every package.

    Results intentionally exclude script content.
    """
    package_list = list(packages)
    spec = get_executor(executor)
    target_name = filename or next_managed_filename(package_list, executor=executor, storage_root=storage_root)
    if not is_managed_filename(target_name):
        raise ValueError("Auto Execute filename must be DENG-managed")
    raw = _script_bytes(script)
    results: list[dict[str, Any]] = []
    for package in package_list:
        directory = spec.autoexecute_dir(package, storage_root=storage_root)
        target = directory / target_name
        row: dict[str, Any] = {
            "package": package,
            "path": str(target),
            "filename": target_name,
            "byte_count": len(raw),
            "success": False,
            "error": "",
        }
        try:
            directory.mkdir(parents=True, exist_ok=True)
            if target.exists():
                row["error"] = "file exists; not overwritten"
            else:
                target.write_bytes(raw)
                row["success"] = True
        except PermissionError as exc:
            row["error"] = f"permission denied: {exc}"
        except OSError as exc:
            row["error"] = f"directory create/write failed: {exc}"
        results.append(row)
    return results


def write_detection_script(
    packages: Iterable[str],
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
    port: int | None = None,
    token: str | None = None,
) -> list[dict[str, Any]]:
    """Drop the DENG detection bootstrap (``deng.txt``) into each package's
    autoexecute folder, alongside the user's own scripts.

    Unlike :func:`write_script_to_packages`, this OVERWRITES an existing
    ``deng.txt`` (the baked-in loopback port/token may legitimately change
    between sessions).  The content is the obscured loadstring bootstrap built
    by :mod:`agent.detection_lua`; it is DENG-owned and not part of the
    user-facing managed-script numbering.
    """
    from . import detection_lua

    spec = get_executor(executor)
    results: list[dict[str, Any]] = []
    for package in packages:
        directory = spec.autoexecute_dir(package, storage_root=storage_root)
        target = directory / detection_lua.DETECTION_FILENAME
        try:
            content = detection_lua.build_deng_txt(package, port=port, token=token)
            raw = content.encode("utf-8")
        except Exception as exc:  # noqa: BLE001
            results.append(
                {
                    "package": package,
                    "path": str(target),
                    "filename": detection_lua.DETECTION_FILENAME,
                    "byte_count": 0,
                    "success": False,
                    "error": f"build failed: {exc}",
                }
            )
            continue
        row: dict[str, Any] = {
            "package": package,
            "path": str(target),
            "filename": detection_lua.DETECTION_FILENAME,
            "byte_count": len(raw),
            "success": False,
            "error": "",
        }
        try:
            directory.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            row["success"] = True
        except PermissionError as exc:
            row["error"] = f"permission denied: {exc}"
        except OSError as exc:
            row["error"] = f"directory create/write failed: {exc}"
        results.append(row)
    return results


def remove_detection_script(
    packages: Iterable[str],
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
) -> list[dict[str, Any]]:
    """Delete the DENG detection bootstrap (``deng.txt``) from each package."""
    from . import detection_lua

    spec = get_executor(executor)
    results: list[dict[str, Any]] = []
    for package in packages:
        target = spec.autoexecute_dir(package, storage_root=storage_root) / detection_lua.DETECTION_FILENAME
        row: dict[str, Any] = {
            "package": package,
            "path": str(target),
            "filename": detection_lua.DETECTION_FILENAME,
            "deleted": False,
            "success": False,
            "error": "",
        }
        try:
            if target.exists() and target.is_file():
                target.unlink()
                row["deleted"] = True
            row["success"] = True
        except PermissionError as exc:
            row["error"] = f"permission denied: {exc}"
        except OSError as exc:
            row["error"] = f"delete failed: {exc}"
        results.append(row)
    return results


def remove_script_from_packages(
    packages: Iterable[str],
    filename: str,
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
) -> list[dict[str, Any]]:
    if not is_managed_filename(filename):
        raise ValueError("Refusing to remove non-DENG Auto Execute file")
    spec = get_executor(executor)
    results: list[dict[str, Any]] = []
    for package in packages:
        target = spec.autoexecute_dir(package, storage_root=storage_root) / filename
        row: dict[str, Any] = {
            "package": package,
            "path": str(target),
            "filename": filename,
            "deleted": False,
            "success": False,
            "error": "",
        }
        try:
            if target.exists() and target.is_file():
                target.unlink()
                row["deleted"] = True
            row["success"] = True
        except PermissionError as exc:
            row["error"] = f"permission denied: {exc}"
        except OSError as exc:
            row["error"] = f"delete failed: {exc}"
        results.append(row)
    return results


def remove_all_scripts_from_packages(
    packages: Iterable[str],
    *,
    executor: str = "delta",
    storage_root: Path = DEFAULT_ANDROID_STORAGE_ROOT,
) -> list[dict[str, Any]]:
    spec = get_executor(executor)
    results: list[dict[str, Any]] = []
    for package in packages:
        directory = spec.autoexecute_dir(package, storage_root=storage_root)
        row: dict[str, Any] = {
            "package": package,
            "path": str(directory),
            "deleted_count": 0,
            "success": False,
            "error": "",
        }
        try:
            for path in _existing_managed_files(directory):
                path.unlink()
                row["deleted_count"] += 1
            row["success"] = True
        except PermissionError as exc:
            row["error"] = f"permission denied: {exc}"
        except OSError as exc:
            row["error"] = f"delete failed: {exc}"
        results.append(row)
    return results


def summarize_results(results: Iterable[dict[str, Any]]) -> dict[str, int]:
    rows = list(results)
    return {
        "total": len(rows),
        "success": sum(1 for row in rows if row.get("success")),
        "failure": sum(1 for row in rows if not row.get("success")),
    }
