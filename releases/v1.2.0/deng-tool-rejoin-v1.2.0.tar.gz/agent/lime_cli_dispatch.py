"""Lime/test-latest2 CLI hooks without overlaying v1.3.0 commands.py."""

from __future__ import annotations

import argparse
from typing import Sequence


def _parse_detection_argv(argv: Sequence[str]) -> argparse.Namespace | None:
    if not argv or str(argv[0]).strip().lower() != "detection":
        return None
    parser = argparse.ArgumentParser(prog="deng-rejoin detection", add_help=False)
    parser.add_argument("detection_subcommand", nargs="?", default="speed_test")
    parser.add_argument("--upload-probe", dest="detection_upload_probe", action="store_true")
    parser.add_argument("--scenario", "-s", dest="detection_scenario", default="")
    parser.add_argument("--package", "-p", dest="detection_package", default="")
    ns, _unknown = parser.parse_known_args(list(argv)[1:])
    sub = str(ns.detection_subcommand or "").lower().replace("-", "_").strip()
    if sub not in {"speed_test", "speedtest", ""}:
        print(f"Unknown detection subcommand: {sub}")
        print(
            "Usage: deng-rejoin detection speed-test "
            "[--upload-probe] [--scenario force-close] [--package com.example]"
        )
        return None
    ns.detection_subcommand = "speed_test"
    return ns


def try_dispatch_lime_argv(argv: Sequence[str]) -> int | None:
    """Run Lime-only CLI when argv starts with ``detection``; else return None."""
    ns = _parse_detection_argv(argv)
    if ns is None:
        if argv and str(argv[0]).strip().lower() == "detection":
            return 2
        return None
    from .detection_speed_test import run_speed_test_cli

    pkg = str(ns.detection_package or "").strip()
    if not pkg:
        try:
            from .config import load_config

            cfg = load_config()
            entries = cfg.get("roblox_packages") or []
            if entries and isinstance(entries[0], dict):
                pkg = str(entries[0].get("package") or "").strip()
        except Exception:  # noqa: BLE001
            pkg = ""
    return run_speed_test_cli(
        package=pkg,
        scenario=str(ns.detection_scenario or "").strip(),
        upload_probe=bool(ns.detection_upload_probe),
    )
