#!/usr/bin/env python3
from __future__ import annotations
import subprocess as _subprocess
import sys
from pathlib import Path
try:
    if hasattr(_subprocess, "_USE_VFORK"):
        _subprocess._USE_VFORK = False
    if hasattr(_subprocess, "_USE_POSIX_SPAWN"):
        _subprocess._USE_POSIX_SPAWN = False
except Exception:
    pass
_ENTRY_ROOT = Path(__file__).resolve().parent
_INSTALL_ROOT = _ENTRY_ROOT.parent
def _dispatch_install_safe_version(argv):
    if not argv or argv[0] not in {{"version", "--version"}}:
        return None
    version_script = _ENTRY_ROOT / "version_standalone.py"
    if not version_script.is_file():
        return 1
    import runpy
    try:
        runpy.run_path(str(version_script), run_name="__main__")
    except SystemExit as exc:
        code = exc.code
        if code is None:
            return 0
        if isinstance(code, int):
            return code
        return 1
    return 0
if __name__ == "__main__":
    _version_rc = _dispatch_install_safe_version(sys.argv[1:])
    if _version_rc is not None:
        raise SystemExit(_version_rc)
if __package__ in {{None, ""}}:
    sys.path.insert(0, str(_INSTALL_ROOT))
    from agent.commands import main
else:
    from .commands import main
if __name__ == "__main__":
    _lime_rc = None
    try:
        if __package__ in {{None, ""}}:
            from agent.lime_cli_dispatch import try_dispatch_lime_argv
        else:
            from .lime_cli_dispatch import try_dispatch_lime_argv
        _lime_rc = try_dispatch_lime_argv(sys.argv[1:])
    except Exception:
        _lime_rc = None
    if _lime_rc is not None:
        raise SystemExit(_lime_rc)
    raise SystemExit(main())
