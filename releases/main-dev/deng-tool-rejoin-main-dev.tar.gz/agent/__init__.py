from . import _protected_runtime as _dpr
_dpr.install()
__all__ = ["__version__"]
__version__ = 'main-dev'
