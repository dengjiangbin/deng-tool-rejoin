"""Safe account-display-name detection for Roblox package rows.

Read-only. Does not modify app data. Logs only package + outcome — never raw
file contents, tokens, or cookies.
"""

from __future__ import annotations

import json
import logging
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from . import android, root_access
from .config import validate_account_username, validate_package_name

_log = logging.getLogger("deng_tool_rejoin")

_USERNAME_CACHE: dict[str, str] = {}

FORBIDDEN_KEY_MARKERS = frozenset(
    (
        "bearer",
        "cookie",
        "credential",
        "csrf",
        "pass",
        "password",
        "roblosecurity",
        "secret",
        "session",
        "ticket",
        "token",
        "refresh",
        "jwt",
        "browser",
        "webview",
    )
)

# Prefer exact login username keys over display-oriented keys.
# Keys with score 0 are numeric IDs (not usernames) — they are skipped by the parser.
# Keys not present default to 0 (skipped) unless they contain user-hint substrings (see _pref_key_score).
_PREF_KEY_SCORES: dict[str, int] = {
    # --- Strong login username keys ---
    "username": 100,
    "user_name": 100,
    "roblox_username": 100,
    "robloxusername": 100,
    "current_username": 100,
    "currentusername": 100,
    "logged_in_username": 100,
    "loggedinusername": 100,
    "rbx_username": 100,
    "rbx_user": 100,
    "rbxusername": 100,
    "account_username": 98,
    "accountusername": 98,
    "account_name": 98,
    "accountname": 98,
    "login_name": 95,
    "loginname": 95,
    "username_lower": 95,
    "player_username": 92,
    "playerusername": 92,
    "player_name": 92,
    "last_username": 85,
    "lastusername": 85,
    "login": 85,
    "screenname": 88,
    "screen_name": 88,
    # --- Display/nick keys (lower priority) ---
    "display_name": 80,
    "displayname": 80,
    "nickname": 75,
    "nick": 70,
    "handle": 70,
    "name": 50,
    # --- Numeric ID keys: explicitly score 0 so username parser skips them ---
    "userid": 0,
    "user_id": 0,
    "roblox_user_id": 0,
    "robloxuserid": 0,
    "authenticateduserid": 0,
    "authenticated_user_id": 0,
    "playerid": 0,
    "player_id": 0,
    "accountid": 0,
    "account_id": 0,
}

# Email pattern for rejection — username must NOT look like an email address.
_EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")

_ROBLOX_USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
# Display names: printable, reasonable length; no URLs or token shapes
_MAX_DISPLAY_LEN = 32
_MAX_USERNAME_LEN = 20

# Keys likely to contain a numeric Roblox user ID (higher = more authoritative).
# This is an explicit allowlist: only keys in this dict are ever read for user ID purposes.
# Only plain numeric integer values are accepted — no token/hash/UUID shapes.
_USER_ID_KEY_SCORES: dict[str, int] = {
    # Highest confidence: directly named user ID fields
    "userid": 100,
    "user_id": 100,
    "robloxuserid": 100,
    "roblox_user_id": 100,
    # Roblox-internal authenticated user ID field
    "authenticateduserid": 95,
    "authenticated_user_id": 95,
    # Common login state fields
    "currentuserid": 90,
    "current_user_id": 90,
    "loggedinuserid": 90,
    "logged_in_user_id": 90,
    "activeuserid": 88,
    "active_user_id": 88,
    # Account-scoped fields
    "accountuserid": 85,
    "account_user_id": 85,
    # Player-scoped fields
    "playeruserid": 80,
    "player_user_id": 80,
    "playerid": 78,
    "player_id": 78,
    # Generic account ID (lower confidence — accept only if no better key found)
    "accountid": 60,
    "account_id": 60,
    # Bare "id" — very low confidence, only used as last resort
    "id": 30,
}
# Roblox user IDs: 1 to ~9 billion (current ceiling ~7B)
_ROBLOX_USER_ID_RE = re.compile(r"^\d{1,10}$")
_ROBLOX_USER_ID_MAX = 9_999_999_999

# Hook for tests: optional (db_path) -> username or None
_sqlite_username_hook: Callable[[str], str | None] | None = None


def set_sqlite_username_hook(cb: Callable[[str], str | None] | None) -> None:
    """Test-only: register a callback to simulate SQLite username extraction."""
    global _sqlite_username_hook
    _sqlite_username_hook = cb


@dataclass(frozen=True)
class AccountDetectionResult:
    username: str
    source: str
    user_id: int | None = None   # Roblox numeric user ID when detected alongside username
    is_display_name_only: bool = False  # True when only a displayName was found (needs confirmation)


def is_sensitive_key_name(name: str) -> bool:
    if not name or not isinstance(name, str):
        return True
    lowered = name.lower().strip()
    if ".roblosecurity" in lowered or "roblosecurity" in lowered:
        return True
    return any(marker in lowered for marker in FORBIDDEN_KEY_MARKERS)


def is_email_address(value: str | None) -> bool:
    """Return True if value looks like an email address (must be rejected as username)."""
    if not value:
        return False
    return bool(_EMAIL_RE.search(str(value).strip()))


def is_sensitive_value(value: str | None) -> bool:
    if value is None:
        return True
    s = str(value).strip()
    if not s:
        return True
    low = s.lower()
    if "roblosecurity" in low or ".roblosecurity" in low:
        return True
    if any(x in low for x in ("sessionid", "session_id", "cookie:", "bearer ", "authorization:")):
        return True
    if re.search(r"https?://", s):
        return True
    if re.fullmatch(r"[A-Za-z0-9+/=._-]{40,}", s):
        return True
    return False


def sanitize_detected_username(value: str | None) -> str:
    if value is None:
        return ""
    s = " ".join(str(value).strip().split())
    if len(s) > 80:
        s = s[:80].rstrip()
    return s


def get_cached_account_username(package_name: str) -> str | None:
    try:
        pkg = validate_package_name(package_name)
    except Exception:
        return None
    return _USERNAME_CACHE.get(pkg)


def set_cached_account_username(package_name: str, username: str) -> None:
    pkg = validate_package_name(package_name)
    cleaned = sanitize_detected_username(username)
    if cleaned:
        _USERNAME_CACHE[pkg] = cleaned
    elif pkg in _USERNAME_CACHE:
        del _USERNAME_CACHE[pkg]


def _settings(config: dict[str, Any] | None) -> dict[str, Any]:
    from .config import default_config

    base = default_config()["account_detection"]
    if not config:
        return dict(base)
    raw = config.get("account_detection")
    if isinstance(raw, dict):
        merged = dict(base)
        merged.update({k: v for k, v in raw.items() if k in merged})
        return merged
    return dict(base)


def is_safe_username_value(value: str | None) -> bool:
    """True if value looks like a Roblox-style login username (strict)."""
    if value is None:
        return False
    cleaned = str(value).strip()
    if not cleaned or len(cleaned) > _MAX_USERNAME_LEN:
        return False
    if is_sensitive_value(cleaned):
        return False
    if is_email_address(cleaned):
        return False
    return _ROBLOX_USERNAME_RE.fullmatch(cleaned) is not None


def is_safe_display_name_value_strict(value: str | None) -> bool:
    """Looser check for display names — spaces/apostrophes allowed, no emails."""
    if value is None:
        return False
    cleaned = str(value).strip()
    if not cleaned or len(cleaned) > _MAX_DISPLAY_LEN:
        return False
    if is_sensitive_value(cleaned):
        return False
    if is_email_address(cleaned):
        return False
    if re.search(r"[=/\\{}\[\]<>]", cleaned):
        return False
    return bool(re.fullmatch(r"[A-Za-z0-9_ .'-]{1,32}", cleaned))


def is_safe_display_name_value(value: str | None) -> bool:
    """Looser check for display names (spaces allowed, capped length)."""
    if value is None:
        return False
    cleaned = str(value).strip()
    if not cleaned or len(cleaned) > _MAX_DISPLAY_LEN:
        return False
    if is_sensitive_value(cleaned):
        return False
    if re.search(r"[=/\\{}\[\]<>]", cleaned):
        return False
    return re.fullmatch(r"[A-Za-z0-9_ .'-]{1,32}", cleaned) is not None


def _pref_key_score(key: str) -> int:
    k = (key or "").strip().lower()
    if k in _PREF_KEY_SCORES:
        return _PREF_KEY_SCORES[k]
    if is_sensitive_key_name(k):
        return -999
    # Fallback: keys whose name contains username-like substrings get a low positive score
    # so Roblox-specific or app-specific key names don't silently block detection.
    _USER_HINT_SUBSTRINGS = ("username", "user_name", "display_name", "account_name", "playername", "player_name")
    if any(sub in k for sub in _USER_HINT_SUBSTRINGS):
        return 10
    return 0


def _xml_element_text(el: ET.Element) -> str | None:
    raw = el.attrib.get("value")
    if raw is not None:
        return raw
    if el.text and str(el.text).strip():
        return str(el.text).strip()
    return None


def _is_plausible_user_id(value: str | int | float | None) -> int | None:
    """Return int if value looks like a plausible Roblox user ID, else None.

    Accepts only plain positive integers within the expected Roblox range.
    Rejects anything that looks like a hash, token, or float.
    """
    if value is None:
        return None
    if isinstance(value, float):
        if value != int(value):
            return None
        value = int(value)
    if isinstance(value, int):
        n = value
    else:
        s = str(value).strip()
        if not _ROBLOX_USER_ID_RE.match(s):
            return None
        n = int(s)
    if n < 1 or n > _ROBLOX_USER_ID_MAX:
        return None
    return n


def user_id_from_pref_xml(xml_text: str) -> int | None:
    """Extract a plausible Roblox user ID from Android shared_pref XML.

    Only reads elements whose key is in ``_USER_ID_KEY_SCORES`` (an explicit
    allowlist of known-safe public user ID field names).  Keys in the allowlist
    bypass the general sensitivity gate because they are definitionally numeric
    IDs, not tokens or cookies.  The value itself is validated to be a plain
    positive integer within the expected Roblox user ID range.
    """
    try:
        root_el = ET.fromstring(xml_text)
    except ET.ParseError:
        return None
    best_score = -1
    best_id: int | None = None
    for child in root_el:
        key = (child.attrib.get("name") or "").strip()
        if not key:
            continue
        k = key.lower().replace("-", "_")
        score = _USER_ID_KEY_SCORES.get(k, 0)
        if score <= 0:
            continue  # Not an approved user ID key — skip entirely
        # For keys in our allowlist we skip the general sensitivity gate:
        # these are known public numeric fields, not tokens/cookies.
        raw_val = child.attrib.get("value")
        if raw_val is None and child.text:
            raw_val = str(child.text).strip()
        uid = _is_plausible_user_id(raw_val)
        if uid is not None and score > best_score:
            best_score = score
            best_id = uid
    return best_id


def _user_id_from_json_obj(data: Any, depth: int = 0) -> int | None:
    if depth > 4 or not isinstance(data, dict):
        return None
    best_score = -1
    best_id: int | None = None
    for key, val in data.items():
        if not isinstance(key, str):
            continue
        k = key.lower().replace("-", "_")
        score = _USER_ID_KEY_SCORES.get(k, 0)
        if score <= 0:
            if isinstance(val, dict):
                nested = _user_id_from_json_obj(val, depth + 1)
                if nested:
                    return nested
            continue
        # Known user ID key (allowlist) — check value for a plausible numeric ID.
        uid = _is_plausible_user_id(val)
        if uid is not None and score > best_score:
            best_score = score
            best_id = uid
    return best_id


def user_id_from_json_text(text: str) -> int | None:
    """Extract a plausible Roblox user ID from JSON text."""
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    return _user_id_from_json_obj(data)


def _root_scan_for_user_id(
    package: str,
    timeout: int,
    max_bytes: int,
    root_tool: str = "",
) -> int | None:
    """Root-based scan for a numeric Roblox user ID in shared_prefs XML and JSON files.

    Reads only small, clearly-structured config files.  Never reads tokens or cookies.
    """
    pkg = validate_package_name(package)
    base_sp = f"/data/data/{pkg}/shared_prefs"
    xml_files = root_access.list_root_glob(f"{base_sp}/*.xml", timeout=timeout, max_results=32)
    for abs_path in xml_files[:24]:
        content = _root_read_file_capped(abs_path, max_bytes, timeout)
        if content:
            uid = user_id_from_pref_xml(content)
            if uid:
                fname = abs_path.split("/")[-1]
                _log.debug("Root shared_prefs found user_id in %s", fname)
                return uid

    base_data = f"/data/data/{pkg}"
    max_kb = max(1, max_bytes // 1024)
    inner = (
        f"find '{base_data}' -maxdepth 6 -type f -size -{int(max_kb)}k -name '*.json' "
        f"2>/dev/null | head -20"
    )
    res = root_access.run_root_command(["sh", "-c", inner], timeout=timeout)
    if res.ok and res.stdout:
        prefix = f"/data/data/{pkg}/"
        for abs_path in [ln.strip() for ln in res.stdout.splitlines() if ln.strip().startswith(prefix)]:
            content = _root_read_file_capped(abs_path, max_bytes, timeout)
            if content:
                uid = user_id_from_json_text(content)
                if uid:
                    _log.debug("Root json found user_id in %s", abs_path)
                    return uid

    return None


def detect_roblox_user_id(
    package_name: str,
    *,
    entry: dict[str, Any] | None = None,
    config: dict[str, Any] | None = None,
    use_root: bool = True,
) -> int | None:
    """Detect a Roblox user ID for a package via safe root prefs/JSON scan.

    Only runs during setup — never called from the live supervisor Start loop.
    Returns None if unavailable; never raises.
    """
    try:
        package_name = validate_package_name(package_name)
    except Exception:
        return None

    # Respect existing confirmed config value.
    if entry:
        existing = entry.get("roblox_user_id")
        if isinstance(existing, int) and existing > 0:
            return existing
        if isinstance(existing, str) and existing.isdigit() and int(existing) > 0:
            return int(existing)

    settings = _settings(config)
    if not settings.get("enabled", True):
        return None

    if use_root and settings.get("use_root", True):
        try:
            if root_access.has_root():
                timeout = int(settings.get("scan_timeout_seconds", 8))
                max_kb = int(settings.get("max_file_size_kb", 512))
                # 1. Shared-prefs scan (fast, text-based)
                uid = _root_scan_for_user_id(package_name, timeout, max_kb * 1024)
                if uid:
                    _log.info("Root-detected user_id=%s for %s via shared_prefs", uid, package_name)
                    return uid
                # 2. SQLite scan (Setup-only; never called from supervisor hot loop)
                try:
                    from . import sqlite_account_detect as _sqdet
                    sqr = _sqdet.scan_package_dbs(
                        package_name,
                        max_bytes=max_kb * 1024,
                        max_files=5,
                        scan_timeout=timeout,
                    )
                    if sqr.user_id > 0:
                        _log.info(
                            "SQLite-detected user_id=%s for %s via %s",
                            sqr.user_id, package_name, sqr.source,
                        )
                        return sqr.user_id
                except Exception as _sqe:  # noqa: BLE001
                    _log.debug("SQLite user_id scan error for %s: %s", package_name, _sqe)
        except Exception as exc:  # noqa: BLE001
            _log.debug("Root user_id scan error for %s: %s", package_name, exc)

    # Non-root: try direct file read (typically requires the process to run as the app)
    for path in _candidate_pref_files(package_name):
        try:
            if path.stat().st_size > 65_536:
                continue
            uid = user_id_from_pref_xml(path.read_text(encoding="utf-8", errors="ignore"))
            if uid:
                return uid
        except OSError:
            continue

    return None


def username_from_pref_xml(xml_text: str) -> tuple[str | None, bool]:
    """Extract the best-scoring safe username from Android shared_pref XML.

    Returns ``(username, is_display_name_only)`` where ``is_display_name_only``
    is ``True`` when the best result is a display name (not a strict login username).
    """
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return None, False
    best_key = (-1, -1)  # (field_score, type_weight) type_weight: 2=login, 1=display
    best: str | None = None
    best_tw = 0
    for child in root:
        key = (child.attrib.get("name") or "").strip()
        if not key or is_sensitive_key_name(key):
            continue
        raw_val = _xml_element_text(child)
        if raw_val is None or is_sensitive_value(raw_val):
            continue
        if is_email_address(raw_val):
            continue
        candidate = sanitize_detected_username(raw_val)
        if not candidate:
            continue
        score = _pref_key_score(key)
        if score <= 0:
            continue
        if is_safe_username_value(candidate):
            tw = 2
        elif is_safe_display_name_value(candidate):
            tw = 1
        else:
            continue
        if key.lower() == "name" and tw != 2:
            continue
        rank = (score, tw)
        if rank > best_key:
            best_key = rank
            best = candidate
            best_tw = tw
    return best, (best_tw == 1 and best is not None)


def _clean_username(value: str) -> str:
    return sanitize_detected_username(value)


def _candidate_pref_files(package: str) -> list[Path]:
    base = Path("/data/data") / validate_package_name(package) / "shared_prefs"
    try:
        if not base.exists() or not base.is_dir():
            return []
    except PermissionError:
        _log.debug(
            "Permission denied checking %s — root may be needed for username auto-detect", base
        )
        return []
    hints = ("account", "profile", "settings", "user", "username", "pkg_preferences", "roblox")
    candidates: list[Path] = []
    try:
        for path in sorted(base.glob("*.xml")):
            name = path.name.lower()
            if any(h in name for h in hints):
                candidates.append(path)
        if not candidates:
            candidates = sorted(base.glob("*.xml"))[:12]
    except PermissionError:
        _log.debug("Permission denied listing %s — skipping", base)
    return candidates[:24]


def detect_username_from_safe_prefs(
    package: str, *, max_bytes: int | None = None
) -> tuple[str | None, bool]:
    """Return ``(username, is_display_name_only)`` from non-root shared_prefs scan."""
    limit = max_bytes or 64_000
    for path in _candidate_pref_files(package):
        try:
            if path.stat().st_size > limit:
                continue
            username, display_only = username_from_pref_xml(
                path.read_text(encoding="utf-8", errors="ignore")
            )
        except OSError:
            continue
        if username:
            return username, display_only
    return None, False


def detect_android_app_label(package: str) -> str | None:
    package = validate_package_name(package)
    result = android.run_command(["dumpsys", "package", package], timeout=8)
    if not result.ok:
        return None
    generic = {"roblox", "roblox player", "roblox app"}
    for line in result.stdout.splitlines():
        stripped = line.strip()
        lowered = stripped.lower()
        if not lowered.startswith("application-label"):
            continue
        _, _, raw_label = stripped.partition(":")
        label = raw_label.strip().strip("'\"")
        if label.lower() in generic:
            continue
        if is_safe_username_value(label) or is_safe_display_name_value(label):
            return _clean_username(label)
    return None


def _root_read_file_capped(abs_path: str, max_bytes: int, timeout: int, _root_tool: str = "") -> str | None:
    """Read a root-protected file capped at max_bytes.  Uses root_access module."""
    if max_bytes <= 0:
        return None
    content = root_access.read_root_file(abs_path, max_bytes=max_bytes, timeout=timeout)
    return content if content else None


def _root_read_shared_prefs_for_username(
    package: str, max_bytes: int, timeout: int, root_tool: str = ""
) -> tuple[str | None, bool]:
    """Targeted root-based shared_prefs reader.

    Returns ``(username, is_display_name_only)``.
    Faster than a full find scan because it directly lists the shared_prefs directory and
    reads hint-matching XML files in priority order. Used as a first-pass before the full
    find-based scan in _root_scan_package_data.
    """
    pkg = validate_package_name(package)
    base = f"/data/data/{pkg}/shared_prefs"
    files = root_access.list_root_glob(f"{base}/*.xml", timeout=timeout, max_results=32)
    if not files:
        return None, False
    _hints = ("account", "profile", "settings", "user", "username", "pkg_preferences", "roblox", "rbx")
    filenames = [f.split("/")[-1] for f in files]
    priority = [f for f in files if any(h in f.lower() for h in _hints)]
    fallback = [f for f in files if f not in priority]
    ordered = (priority + fallback)[:24]
    for abs_path in ordered:
        content = _root_read_file_capped(abs_path, max_bytes, timeout)
        if not content:
            continue
        username, display_only = username_from_pref_xml(content)
        if username:
            fname = abs_path.split("/")[-1]
            _log.debug("Root shared_prefs found username in %s", fname)
            return username, display_only
    return None, False


def _root_list_scan_files(package: str, max_kb: int, timeout: int, root_tool: str = "") -> list[str]:
    pkg = validate_package_name(package)
    base = f"/data/data/{pkg}"
    # find: only under this package, caps count and file size
    inner = (
        f"find '{base}' -maxdepth 6 -type f -size -{int(max_kb)}k "
        f"\\( -path '*/shared_prefs/*.xml' -o -name '*.json' \\) "
        f"2>/dev/null | head -80"
    )
    result = root_access.run_root_command(["sh", "-c", inner], timeout=timeout)
    if not result.ok or result.timed_out:
        return []
    lines = [ln.strip() for ln in (result.stdout or "").splitlines() if ln.strip().startswith("/")]
    return lines


def _username_from_json_text(text: str) -> str | None:
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    return _username_from_json_obj(data)


def _json_key_score(key: str) -> int:
    k = str(key or "").strip().lower().replace("-", "_")
    if k in _PREF_KEY_SCORES:
        return _PREF_KEY_SCORES[k]
    if is_sensitive_key_name(k):
        return -999
    return 0


def _username_from_json_obj(data: Any, depth: int = 0) -> str | None:
    if depth > 3:
        return None
    if isinstance(data, dict):
        best_key = (-1, -1)
        best: str | None = None
        for key, val in data.items():
            if not isinstance(key, str):
                continue
            if is_sensitive_key_name(key):
                continue
            sk = _json_key_score(key)
            if sk == 0:
                continue
            if isinstance(val, dict):
                nested = _username_from_json_obj(val, depth + 1)
                if nested:
                    return nested
                continue
            if not isinstance(val, str):
                continue
            if is_sensitive_value(val):
                continue
            cand = sanitize_detected_username(val)
            if not cand:
                continue
            if is_safe_username_value(cand):
                tw = 2
            elif is_safe_display_name_value(cand):
                tw = 1
            else:
                continue
            if key.lower() == "name" and tw != 2:
                continue
            rank = (sk, tw)
            if rank > best_key:
                best_key = rank
                best = cand
        return best
    return None


def _try_sqlite_roblox_user(db_abs: str) -> str | None:
    if _sqlite_username_hook is not None:
        try:
            u = _sqlite_username_hook(db_abs)
        except Exception:
            return None
        if u and sanitize_detected_username(u):
            c = sanitize_detected_username(u)
            if is_safe_username_value(c) or is_safe_display_name_value(c):
                return c
        return None
    return None


def _root_scan_package_data(
    package: str, settings: dict[str, Any]
) -> tuple[str | None, str | None, bool]:
    """Scan package data for username via root.

    Returns ``(username, source, is_display_name_only)``.
    """
    timeout = int(settings.get("scan_timeout_seconds", 8))
    max_kb = int(settings.get("max_file_size_kb", 512))
    max_bytes = max_kb * 1024

    if not root_access.has_root():
        _log.info("Root unavailable, skipped package data scan")
        return None, None, False

    # Fast first pass: directly read shared_prefs XML via root (no find needed).
    fast_user, fast_display_only = _root_read_shared_prefs_for_username(package, max_bytes, timeout)
    if fast_user:
        u = sanitize_detected_username(fast_user)
        if u:
            return u, "root_shared_prefs", fast_display_only

    # Full scan: find XML/JSON files under the package data directory.
    paths = _root_list_scan_files(package, max_kb=max_kb, timeout=timeout)
    best: str | None = None
    best_src: str | None = None
    best_rank: tuple[int, int] = (-1, -1)
    best_display_only = False
    for abs_path in paths:
        if not abs_path.startswith(f"/data/data/{validate_package_name(package)}/"):
            continue
        if abs_path.endswith(".db"):
            # SQLite databases — try real detection first, then fall back to hook
            db_user: str | None = None
            db_uid: int = 0
            db_display_only = False
            db_src = "root_sqlite"  # keep legacy label as default
            try:
                from . import sqlite_account_detect as _sqdet
                r = _sqdet._scan_db_file(abs_path, abs_path)
                if r.user_id > 0:
                    db_uid = r.user_id
                    db_src = "sqlite_user_id"
                elif r.username:
                    db_user = r.username
                    db_display_only = r.is_display_name_only
                    db_src = r.source  # e.g. "sqlite_username" or "sqlite_display_name_hint"
            except Exception:  # noqa: BLE001
                pass
            if db_uid:
                # User ID found — handled by detect_roblox_user_id path; skip username flow
                continue
            if not db_user:
                # Fall back to test hook (backwards-compatible source label)
                db_user = _try_sqlite_roblox_user(abs_path)
                db_src = "root_sqlite"
            if db_user:
                cand = sanitize_detected_username(db_user)
                if cand:
                    rank = (100 if is_safe_username_value(cand) else 50, 2)
                    if rank > best_rank:
                        best, best_src, best_rank, best_display_only = cand, db_src, rank, db_display_only
            continue
        raw = _root_read_file_capped(abs_path, min(max_bytes, 262_144), timeout)
        if not raw:
            continue
        if abs_path.endswith(".xml"):
            u, d_only = username_from_pref_xml(raw)
            if u:
                cand = sanitize_detected_username(u)
                rank = (95, 2 if is_safe_username_value(cand) else 1)
                if rank > best_rank:
                    best, best_src, best_rank, best_display_only = cand, "root_pref", rank, d_only
        elif abs_path.endswith(".json"):
            u = _username_from_json_text(raw)
            if u:
                cand = sanitize_detected_username(u)
                rank = (90, 2 if is_safe_username_value(cand) else 1)
                if rank > best_rank:
                    best, best_src, best_rank, best_display_only = cand, "root_json", rank, False
    if best:
        return best, best_src or "root_scan", best_display_only
    return None, None, False


def detect_account_username(
    package_name: str,
    *,
    entry: dict[str, Any] | None = None,
    config: dict[str, Any] | None = None,
    use_root: bool = True,
    respect_config_manual: bool = True,
) -> AccountDetectionResult | None:
    """Resolve display username for one package (config → label → prefs → root scan)."""
    package_name = validate_package_name(package_name)
    settings = _settings(config)
    if not settings.get("enabled", True):
        return None

    if respect_config_manual and entry:
        src = str(entry.get("username_source") or "").strip().lower()
        manual_user = validate_account_username(entry.get("account_username", ""))
        if src == "manual" and manual_user:
            u = sanitize_detected_username(manual_user)
            return AccountDetectionResult(u, "config_manual") if u else None

    label = detect_android_app_label(package_name)
    if label:
        u = sanitize_detected_username(label)
        if u:
            if settings.get("cache_detected_usernames", True):
                set_cached_account_username(package_name, u)
            _log.info("Detected username for %s: %s", package_name, u)
            return AccountDetectionResult(u, "android_app_label")

    pref_user, pref_display_only = detect_username_from_safe_prefs(
        package_name, max_bytes=settings.get("max_file_size_kb", 512) * 1024
    )
    if pref_user:
        u = sanitize_detected_username(pref_user)
        if u:
            if settings.get("cache_detected_usernames", True):
                set_cached_account_username(package_name, u)
            _log.info("Detected username for %s: %s", package_name, u)
            return AccountDetectionResult(u, "detected_safe_pref", is_display_name_only=pref_display_only)

    if use_root and settings.get("use_root", True):
        try:
            root_user, rsrc, root_display_only = _root_scan_package_data(package_name, settings)
        except OSError:
            root_user, rsrc, root_display_only = None, None, False
        if root_user:
            u = sanitize_detected_username(root_user)
            if u:
                if settings.get("cache_detected_usernames", True):
                    set_cached_account_username(package_name, u)
                _log.info("Detected username for %s: %s", package_name, u)
                return AccountDetectionResult(u, rsrc or "root_scan", is_display_name_only=root_display_only)

    _log.info("No username found for %s", package_name)
    return None


def detect_account_usernames_for_packages(
    packages: list[dict[str, Any]],
    *,
    config: dict[str, Any] | None = None,
    use_root: bool = True,
    respect_config_manual: bool = False,
) -> list[tuple[dict[str, Any], AccountDetectionResult | None]]:
    """Run detection per package entry. Returns (entry, result) pairs in order."""
    out: list[tuple[dict[str, Any], AccountDetectionResult | None]] = []
    for entry in packages:
        if not isinstance(entry, dict):
            continue
        pkg = str(entry.get("package") or "").strip()
        if not pkg:
            continue
        try:
            validate_package_name(pkg)
        except Exception:
            out.append((entry, None))
            continue
        res = detect_account_username(
            pkg,
            entry=entry,
            config=config,
            use_root=use_root,
            respect_config_manual=respect_config_manual,
        )
        out.append((entry, res))
    return out


def detect_account_username_for_package(package: str) -> AccountDetectionResult | None:
    """Backward-compatible helper: no config entry (setup wizard)."""
    return detect_account_username(package, entry=None, config=None, use_root=True, respect_config_manual=False)
