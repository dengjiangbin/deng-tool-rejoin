from __future__ import annotations
import importlib.abc, importlib.machinery, marshal, sys, zlib
from pathlib import Path
_B=None
class _L(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in _m():
            return importlib.machinery.ModuleSpec(fullname, self, origin=_o(fullname))
        return None
    def create_module(self, spec):
        return None
    def exec_module(self, module):
        code=_m()[module.__name__]
        module.__file__=_o(module.__name__)
        module.__loader__=self
        module.__package__=module.__name__.rpartition(".")[0]
        exec(code, module.__dict__)
def _o(fullname):
    return str(Path(__file__).resolve().parent.parent / (fullname.replace(".","/")+".py"))
def _m():
    global _B
    if _B is None:
        p=Path(__file__).with_name(".deng_runtime.bin")
        _B=marshal.loads(zlib.decompress(p.read_bytes()))
    return _B
def install():
    if not any(isinstance(x,_L) for x in sys.meta_path):
        sys.meta_path.insert(0,_L())
install()
