#!/usr/bin/env python3
from __future__ import annotations
import subprocess as _subprocess
import sys
from pathlib import Path
try:
    if hasattr(_subprocess, "_USE_VFORK"):
        _subprocess._USE_VFORK = False
    if hasattr(_subprocess, "_USE_POSIX_SPAWN"):
        _subprocess._USE_POSIX_SPAWN = False
except Exception:
    pass
if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import agent._protected_runtime  # noqa: F401
from agent.commands import main
if __name__ == "__main__":
    _lime_rc = None
    try:
        if __package__ in {None, ""}:
            from agent.lime_cli_dispatch import try_dispatch_lime_argv
        else:
            from .lime_cli_dispatch import try_dispatch_lime_argv
        _lime_rc = try_dispatch_lime_argv(sys.argv[1:])
    except Exception:
        _lime_rc = None
    if _lime_rc is not None:
        raise SystemExit(_lime_rc)
    raise SystemExit(main())
