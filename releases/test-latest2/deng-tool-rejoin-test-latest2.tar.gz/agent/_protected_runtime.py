from __future__ import annotations
import base64, hashlib, importlib.abc, importlib.machinery, json, marshal, sys, zlib
from pathlib import Path
_N=22740157857269330841523733066182332177190020495145240151840467876644404906648435472219875306460845386919939783497644249388745573933925390564651952715694205421604057887548451297513192575189510625421542312195751683655288021880974908103269291758136089568630835773045247428396002933513842010688217965644445106195929804682987305380261804218292686415803703162429608586588761359544512010020936868410112235233444118451373912491162554069983040822573181972213299225231150938091052728744917238112611753852516246932207288629678773486973374941586161232303534692838374590810033129954900289178195604553402012548964464749770591611407
_E=65537
_FALLBACK_INSTALL_ENDPOINT='/install/test/latest2'
_MINP=2
_B=None
class IntegrityError(RuntimeError): pass
class _L(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in _m():
            return importlib.machinery.ModuleSpec(fullname, self, origin=_o(fullname))
        return None
    def create_module(self, spec):
        return None
    def exec_module(self, module):
        code=_m()[module.__name__]
        module.__file__=_o(module.__name__)
        module.__loader__=self
        module.__package__=module.__name__.rpartition(".")[0]
        exec(code, module.__dict__)
def _o(fullname):
    return str(Path(__file__).resolve().parent.parent / (fullname.replace(".","/")+".py"))
def _repair_cmd(root):
    base="https://rejoin.deng.my.id"; endpoint=""
    try:
        raw=(root/".installed-build.json").read_text(encoding="utf-8", errors="replace")
        meta=json.loads(raw)
        base=str(meta.get("install_api") or base).strip().rstrip("/") or base
        endpoint=str(meta.get("installer_url") or "").strip()
        if endpoint.startswith(base):
            return "curl -fsSL "+endpoint+" -o install.sh && bash install.sh"
    except Exception:
        pass
    try:
        line=(root/".install_api").read_text(encoding="utf-8", errors="replace").strip().splitlines()[0].strip()
        if line:
            base=line.rstrip("/")
    except Exception:
        pass
    try:
        version=(root/".install_version").read_text(encoding="utf-8", errors="replace").strip().splitlines()[0].strip()
    except Exception:
        version=""
    if version and version!="main-dev":
        endpoint=base+"/install/"+version
    elif _FALLBACK_INSTALL_ENDPOINT:
        endpoint=base+_FALLBACK_INSTALL_ENDPOINT
    else:
        endpoint=base+"/install/"+("test"+"/latest")
    return "curl -fsSL "+endpoint+" -o install.sh && bash install.sh"
def _err():
    root=Path(__file__).resolve().parent.parent
    sys.stderr.write("[!] DENG Tool: Rejoin integrity check failed.\n[!] Your installation may be incomplete, outdated, or modified.\n[*] Please reinstall using the official command:\n"+_repair_cmd(root)+"\n")
def _b64u(x):
    return base64.urlsafe_b64decode(x.encode()+b"="*((4-len(x)%4)%4))
def _canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
def _rsav(sig, msg):
    k=(_N.bit_length()+7)//8
    if len(sig)!=k: return False
    em=pow(int.from_bytes(sig,"big"),_E,_N).to_bytes(k,"big")
    di=bytes.fromhex("3031300d060960864801650304020105000420")+hashlib.sha256(msg).digest()
    return em==b"\x00\x01"+b"\xff"*(k-len(di)-3)+b"\x00"+di
def _verify():
    root=Path(__file__).resolve().parent.parent
    mp=root/"RELEASE-MANIFEST.json"; sp=root/"RELEASE-MANIFEST.sig"
    try:
        m=json.loads(mp.read_text(encoding="utf-8"))
        sig=json.loads(sp.read_text(encoding="utf-8"))
        if m.get("project")!="deng-tool-rejoin" or int(m.get("client_protocol") or 0)<_MINP:
            raise IntegrityError()
        if sig.get("algorithm")!="RS256" or not _rsav(_b64u(sig.get("signature","")), _canon(m)):
            raise IntegrityError()
        for item in m.get("files", []):
            p=str(item.get("path") or "")
            if not p or p.startswith("/") or ".." in p.replace("\\","/").split("/"):
                raise IntegrityError()
            raw=(root/p).read_bytes()
            if len(raw)!=int(item.get("size", -1)) or hashlib.sha256(raw).hexdigest()!=item.get("sha256"):
                raise IntegrityError()
    except Exception:
        _err()
        raise SystemExit(126)
def _m():
    global _B
    if _B is None:
        _verify()
        p=Path(__file__).with_name(".deng_runtime.bin")
        _B=marshal.loads(zlib.decompress(p.read_bytes()))
    return _B
def install():
    if not any(isinstance(x,_L) for x in sys.meta_path):
        sys.meta_path.insert(0,_L())
install()
